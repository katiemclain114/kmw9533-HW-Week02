﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ExitStore : MonoBehaviour
{
    public bool onStore;
    private void Update()
    {
        if (onStore)
        {
            if (Input.GetKeyDown(KeyCode.E))
            {
                SceneManager.LoadScene(0);
            }
        }
    }

    private void OnCollisionEnter2D(Collision2D other)
    {
        onStore = true;
    }

    private void OnCollisionExit2D(Collision2D other)
    {
        onStore = false;
    }
}
