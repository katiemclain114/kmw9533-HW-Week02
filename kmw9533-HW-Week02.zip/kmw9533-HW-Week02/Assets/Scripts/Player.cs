﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public float speed;

    public static Player instance;

    [HideInInspector] public Vector2 newPos;

    private void Awake()
    {
        if (instance == null)
        {
            DontDestroyOnLoad(gameObject);
            instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void Update()
    {
        if (Input.GetKey(KeyCode.W))
        {
            newPos.y += Time.deltaTime * speed;
        }
        if (Input.GetKey(KeyCode.S))
        {
            newPos.y -= Time.deltaTime * speed;
        }
        if (Input.GetKey(KeyCode.A))
        {
            newPos.x -= Time.deltaTime * speed;
        }
        if (Input.GetKey(KeyCode.D))
        {
            newPos.x += Time.deltaTime * speed;
        }
        transform.position = newPos;
    }
}
