﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Inventory : MonoBehaviour
{
    public static int emptySlotNum;
    public static bool emptySlotFound = false;
    public static bool invFull = false;
    
    public static int[] VeggiesInInv = new int[4];

    public static GameObject[] veggieImages = new GameObject[4];

    public static int money = 0;

    public static Inventory instance;

    public Text moneyText;

    private void Awake()
    {
        if (instance == null)
        {
            DontDestroyOnLoad(gameObject);
            instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void Start()
    {
        moneyText.text = ("Money: $" + money);
        for (int i = 0; i < VeggiesInInv.Length; i++)
        {
            VeggiesInInv[i] = 0;
        }

        for (int i = 0; i < veggieImages.Length; i++)
        {
            veggieImages[i] = GameObject.Find("veggieImage0" + i);
            veggieImages[i].SetActive(false);
        }

        
    }

    private void Update()
    {
        moneyText.text = ("Money: $" + money);
    }


    public static void AddVeggie()
    {
        for (int i = 0; i < VeggiesInInv.Length; i++)
        {
            if (VeggiesInInv[i] == 0)
            {
                emptySlotNum = i;
                emptySlotFound = true;
                //Debug.Log(emptySlotNum);
                break;
            }
            else
            {
                emptySlotFound = false;
            }
        }

        if (emptySlotFound)
        {
            if (emptySlotNum == VeggiesInInv.Length - 1)
            {
                invFull = true;
            }
            VeggiesInInv[emptySlotNum] = 1;
            veggieImages[emptySlotNum].SetActive(true);
        }

    }

    public static void SellVeggie()
    {
        for (int i = VeggiesInInv.Length -1; i >= 0; i--)
        {
            if (VeggiesInInv[i] == 1)
            {
                VeggiesInInv[i] = 0;
                veggieImages[i].SetActive(false);
                invFull = false;
                money++;
                Debug.Log(money);
                break;
            }
        }
    }
}
