﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Veggie : MonoBehaviour
{
    //public Inventory inventory;
    public bool onVeggie;
    private void Update()
    {
        if (onVeggie)
        {
            if (Input.GetKeyDown(KeyCode.E))
            {
                if (Inventory.invFull)
                {
                    Debug.Log("inv is full sry");
                }
                else
                {
                    Debug.Log("pick up veggie");
                    Inventory.AddVeggie();
                    Destroy(gameObject);
                }
            }
        }
    }

    private void OnCollisionStay2D(Collision2D other)
    {
        onVeggie = true;
    }

    private void OnCollisionExit2D(Collision2D other)
    {
        onVeggie = false;
    }
}
