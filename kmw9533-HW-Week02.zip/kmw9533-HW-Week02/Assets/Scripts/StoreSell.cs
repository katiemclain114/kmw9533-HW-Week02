﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StoreSell : MonoBehaviour
{
    public bool onStore = false;

    private void Update()
    {
        if (onStore)
        {
            if (Input.GetKeyDown(KeyCode.E))
            {
                Inventory.SellVeggie();
            }
        }
        
    }

    private void OnCollisionEnter2D(Collision2D other)
    {
        onStore = true;
    }

    private void OnCollisionExit2D(Collision2D other)
    {
        onStore = false;
    }
}
